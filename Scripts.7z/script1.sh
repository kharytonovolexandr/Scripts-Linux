#! /bin/bash
exit=true
    while [[ $exit == true ]];
    do
    #echo "1. Add a new disk to your virtual box with Linux"
    echo " Function menu"
    echo "1. Show all disks"
    echo "2. Show disk space"
    echo "3. Add new partitions"
    echo "4. Make file system"
    echo "5. Mount to folder"
    echo "6. UnMount from folder"
    echo "7. Edit fstab"
    echo "8. Restart system"
    echo "0. Exit."
read -p "Enter menu item: " action
case $action in
1)
sudo fdisk -l
;;
2)
sudo df -Th | grep -E ^"/dev/sd*"

;;
3)
read -r -p "Choose disc you want to make partition:" sdb
sudo fdisk /dev/$sdb
;;
4)
read -r -p "Enter file system you want to make for new partition (ext4, xfs)" fs
sudo mkfs.$fs /dev/$sdb
;;
5)
read -r -p "Enter folder you want to mount to partition" path
read -r -p "Enter partition" sdb1

sudo mount /dev/$sdb1 $path
;;

6)
read -r -p "Enter folder you want to unmount from partition" path
read -r -p "Enter partition" sdb1

sudo umount /dev/$sdb1 $path
;;

7)
read -r -p "Enter partition to add fstab" sdb
uuid="$(blkid | grep -Eo $sdb.* | grep -Eo "UUID=\".*\" T" | grep -Eo "[a-z0-9-]*")"
fs="$(blkid | grep -Eo $sdb.* | grep -Eo "TYPE=\".*\" P" | grep -Eo "[a-z0-9-]*")"
if blkid | grep -Eo $sdb.* | grep -Eo "UUID=\".*\" T" | grep -Eo "[a-z0-9-]*"; 
then
echo "UUID $sdb already exist!"
fi
path="$(df -Th | grep $sdb | awk '{print$7}')"
if cat /etc/fstab | grep $uuid;
then
sed -i '/'$uuid'/d' /etc/fstab
echo "UUID=$uuid $path $fs defaults 0 0" >> /etc/fstab
else
echo "UUID=$uuid $path $fs defaults 0 0" >> /etc/fstab
fi
;;
 0) exit=false
    echo "Good bye";;
    *) echo "Error invalid action"
     exit 1
esac
#uuid="$(blkid | grep -Eo sdb.* | grep -Eo "UUID=\".*\" T" | grep -Eo "[a-z0-9-]*")"
done

