#! /bin/bash
sudo apt-get update
sudo apt-get install -y mysql-server
sudo apt-get -y install php-mysql
systemctl status mysql
read -r -p "Enter new username for database: " uname
sudo mysql_secure_installation
read -r -p "Enter name for new database: " dbname
read -r -p "Enter new password: " passwd
sudo mysql -u$uname -p$passwd -e "Create '$dbname';"
#sudo mysql -u root -p
#sudo mysql -u$uname -p$passwd -e "Drop '$dbname';"
sudo apt-cache search mysql
sudo apt install php libapache2-mod-php
#sudo apt update
sudo apt install php-curl php-gd php-mbstring php-xml php-xmlrpc php-soap php-intl php-zip
sudo apt install apache2
sudo ufw allow in 80/tcp
sudo echo "<Directory /var/www/html/>" >> /etc/apache2/sites-available/wordpress.conf
sudo echo "AllowOverride All" >> /etc/apache2/sites-available/wordpress.conf
sudo echo "</Directory>" >> /etc/apache2/sites-available/wordpress.conf
sudo a2enmod rewrite
sudo apache2ctl configtest
sudo systemctl restart apache2
cd /home/
sudo wget http://wordpress.org/latest.tar.gz
cd /home
sudo tar xzvf latest.tar.gz
sudo touch /home/wordpress/.htaccess
sudo cp /home/wordpress/wp-config-sample.php /home/wordpress/wp-config.php
sudo mkdir /home/wordpress/wp-content/upgrade
sudo rsync -avP /home/wordpress/ /var/www/html/
sudo chown -R www-data:www-data /var/www/html
sudo find /var/www/html/ -type d -exec chmod 750 {} \;
sudo find /var/www/html/ -type f -exec chmod 640 {} \;
# keys="$(curl -s https://api.wordpress.org/secret-key/1.1/salt/)"
# sudo sed -i '/define( 'AUTH_KEY',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'SECURE_AUTH_KEY',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'LOGGED_IN_KEY',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'NONCE_KEY',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'AUTH_SALT',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'SECURE_AUTH_SALT',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'LOGGED_IN_SALT',/d' /var/www/html/wp-config.php
# sudo sed -i '/define( 'NONCE_SALT',/d' /var/www/html/wp-config.php
# sudo echo "$keys" >> /var/www/html/wp-config.php
sudo sed -i 's/define( 'DB_NAME', 'database_name_here' );/define( 'DB_NAME', '$dbname' );/g' /var/www/html/wp-config.php
sudo sed -i 's/define( 'DB_USER', 'username_here' );/define( 'DB_USER', '$uname' );/g' /var/www/html/wp-config.php
sudo sed -i 's/define( 'DB_PASSWORD', 'password_here' );/define( 'DB_PASSWORD', '$passwd' );/g' /var/www/html/wp-config.php
#sudo echo "define('FS_METHOD', 'direct');" >> /var/www/html/wp-config.php
#sudo vim /var/www/html/wp-config.php