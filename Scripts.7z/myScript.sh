#! /bin/bash
n="$(ip addr | grep -E "2: en.*:" | grep -Eo "en.*:")"
ip="$(ip addr | grep -E "enp0s3" | grep -Eo "inet [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+" | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+")"

if cat /etc/os-release | grep -q 'ID_LIKE=debian' 
then
if cat /etc/netplan/50-cloud-init.yaml | grep -q 'network:'
then
 sed -i '/network:/d' /etc/netplan/50-cloud-init.yaml
 echo "network:" > /etc/netplan/50-cloud-init.yaml
fi
 echo "  version: 2" >> /etc/netplan/50-cloud-init.yaml
 echo "  renderer: networkd" >> /etc/netplan/50-cloud-init.yaml
 echo "  ethernets:" >> /etc/netplan/50-cloud-init.yaml
 echo "    $n" >> /etc/netplan/50-cloud-init.yaml
 echo "     dhcp4: false" >> /etc/netplan/50-cloud-init.yaml
 echo "     addresses: ["$ip"/24]" >> /etc/netplan/50-cloud-init.yaml
 read -r -p "Enter gatrway:" gateway
 echo "     gateway4: "$gateway"" >> /etc/netplan/50-cloud-init.yaml
 echo "     nameservers:" >> /etc/netplan/50-cloud-init.yaml
 echo "       addresses: [8.8.8.8,8.8.4.4]" >> /etc/netplan/50-cloud-init.yaml
netplan apply
else
sed -i 's/ONBOOT=no/ONBOOT=yes/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3
sed -i 's/BOOTPROTO=dhcp/BOOTPROTO=static/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3


 # read -r -p "IPADDR:" ipaddr
           
 if cat /etc/sysconfig/network-scripts/ifcfg-enp0s3 | grep -q 'IPADDR=';
      then
        sed -i '/IPADDR/d' /etc/sysconfig/network-scripts/ifcfg-enp0s3
       echo "IPADDR="$ip"" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
         # sed -i 's/IPADDR= | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"/ip addr | grep -E "enp0s3" | grep -Eo "inet [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+" | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3
      else
        echo "IPADDR='$ip'" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
  fi

 read -r -p "Enter NETMASK:" netmask

 if cat /etc/sysconfig/network-scripts/ifcfg-enp0s3 | grep -q "NETMASK="
     then
     sed -i '/NETMASK/d' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     echo "NETMASK="$netmask"" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
     #sed -i 's/NETMASK= | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"/NETMASK= $netmask/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     else
     echo "NETMASK="$netmask"" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
 fi

 read -r -p "Enter GATEWAY:" gateway

 if cat /etc/sysconfig/network-scripts/ifcfg-enp0s3 | grep -q "GATEWAY="
     then
     sed -i '/GATEWAY/d' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     echo "GATEWAY="$gateway"" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
     #sed -i 's/GATEWAY= | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"/GATEWAY= $gateway"/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     else
     echo "GATEWAY="$gateway"" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
 fi
 read -r -p "Enter DNS1:" dns1
 if cat /etc/sysconfig/network-scripts/ifcfg-enp0s3 | grep -q "DNS1="
     then
     sed -i '/DNS1/d' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     echo "DNS1=$dns1" >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
     #sed -i 's/DNS1= | grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"/DNS1= dns1/g' /etc/sysconfig/network-scripts/ifcfg-enp0s3
     else
     echo "DNS1=$dns1"  >> /etc/sysconfig/network-scripts/ifcfg-enp0s3
 fi
fi
